import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

L=1. #Largeur du carré
N=3 #Nombre de points de discretisation par lignes
x=np.linspace(0,L,N)
dx=L/(N-1)
dy=dx
y=np.linspace(0,L,N)
X, Y = np.meshgrid(x, y)
T=200
t=np.arange(T+1)
dt=1 #Pas de temps en jours
D=0.1 #Coeff. Diffusion

lbda=D*dt/(dx**2)

def u_init(x:float,y:float)->float:
    if(x==0 or y==0 or x==L or y==L):
        return 0
    else:
        return 1

def U0(x:np.ndarray)->np.ndarray:
    U=np.diag(np.zeros((len(x))))
    for i in range(len(x)):
        for j in range(len(x)):
            U[i,j]=u_init(x[i],x[j])
    return U

def flux(x:float,y:float)->float:
    return x*(1-y)

def Flux(x:np.ndarray)->np.ndarray:
    FF=np.diag(np.zeros((len(x))))
    for i in range(len(x)):
        for j in range(len(x)):
            FF[i,j]=flux(x[i],x[j])
    return FF

F=Flux(x)
#print(F)

U=U0(x)
Z=U

fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(2, 3, 1, projection='3d')
ax.plot_surface(X, Y, Z, cmap="viridis")

ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Concentration")
ax.set_title("Init.")

plt.tight_layout()
plt.show()

def Mat_x(N:int)->np.ndarray:
    d=np.ones(N*N)*(1-4*lbda)
    d1=np.ones((N*N)-1)*(lbda)
    return np.diag(d)+np.diag(d1,-1)+np.diag(d1,1)

def Mat_y(N:int)->list:
    d = np.ones(N*N-N) * (-lbda)  # Coefficients en dehors de la diagonale principale
    return np.diag(d, -N) + np.diag(d, N)  # Décalage de N pour la liaison en y

def Mat_2D(N:int)->list:
    return Mat_x(N)+Mat_y(N)

M=Mat_2D(N)
print(M)
    
    


